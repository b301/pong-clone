Compiled using 

>g++.exe (x86_64-win32-seh-rev0, Built by MinGW-W64 project) 7.3.0<br>
>Copyright (C) 2017 Free Software Foundation, Inc.<br>
>This is free software; see the source for copying conditions.  There is NO<br>
>warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

And 

>SFML 2.5.1

Makefile is in the repository, execute `mingw32-make.exe` to get the executable.

Enjoy!

Author:
>Kildoes